/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package a1u4;

import java.sql.*;
import java.util.Scanner;
import java.sql.DriverManager;

public class unidad4 {

    private static final String URL = "jdbc:mariadb://localhost:3306/bd_ramiro_espana_ejercicio11";
    private static final String USER = "user_ramiro_espana";
    private static final String PASSWORD = "AbcdeUdeC";

    public static void main(String[] args) {
        try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD)) {
            System.out.println("Conexión exitosa a la base de datos.");

            Scanner scanner = new Scanner(System.in);
            boolean exit = false;

            while (!exit) {
                System.out.println("\nElige una opción:");
                System.out.println("1. Agregar artículo");
                System.out.println("2. Mostrar todos los artículos");
                System.out.println("3. Actualizar un artículo");
                System.out.println("4. Eliminar un artículo");
                System.out.println("5. Consultar artículos con filtros");
                System.out.println("6. Ordenar artículos");
                System.out.println("7. Consultar con tablas relacionadas (JOIN)");
                System.out.println("8. Salir");

                int option = scanner.nextInt();
                scanner.nextLine(); // Limpiar buffer

                switch (option) {
                    case 1:
                        agregarArticulo(connection, scanner);
                        break;
                    case 2:
                        mostrarArticulos(connection);
                        break;
                    case 3:
                        actualizarArticulo(connection, scanner);
                        break;
                    case 4:
                        eliminarArticulo(connection, scanner);
                        break;
                    case 5:
                        consultarConFiltros(connection, scanner);
                        break;
                    case 6:
                        ordenarArticulos(connection, scanner);
                        break;
                    case 7:
                        consultarConJoin(connection);
                        break;
                    case 8:
                        exit = true;
                        break;
                    default:
                        System.out.println("Opción no válida.");
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void agregarArticulo(Connection connection, Scanner scanner) throws SQLException {
        System.out.print("Nombre del artículo: ");
        String nombre = scanner.nextLine();
        System.out.print("Descripción: ");
        String descripcion = scanner.nextLine();
        System.out.print("Precio inicial: ");
        double precio = scanner.nextDouble();
        scanner.nextLine(); // Limpiar buffer

        String query = "INSERT INTO Articulo (nombre, descripcion, precio_inicial) VALUES (?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, nombre);
            stmt.setString(2, descripcion);
            stmt.setDouble(3, precio);
            stmt.executeUpdate();
            System.out.println("Artículo agregado correctamente.");
        }
    }

    private static void mostrarArticulos(Connection connection) throws SQLException {
        String query = "SELECT * FROM Articulo";
        try (Statement stmt = connection.createStatement(); ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                System.out.printf("ID: %d, Nombre: %s, Descripción: %s, Precio: %.2f\n",
                        rs.getInt("id_articulo"), rs.getString("nombre"), rs.getString("descripcion"), rs.getDouble("precio_inicial"));
            }
        }
    }

    private static void actualizarArticulo(Connection connection, Scanner scanner) throws SQLException {
        System.out.print("ID del artículo a actualizar: ");
        int id = scanner.nextInt();
        scanner.nextLine(); 
        System.out.print("Nuevo nombre: ");
        String nombre = scanner.nextLine();
        System.out.print("Nueva descripción: ");
        String descripcion = scanner.nextLine();
        System.out.print("Nuevo precio: ");
        double precio = scanner.nextDouble();
        scanner.nextLine(); 

        String query = "UPDATE Articulo SET nombre = ?, descripcion = ?, precio_inicial = ? WHERE id_articulo = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, nombre);
            stmt.setString(2, descripcion);
            stmt.setDouble(3, precio);
            stmt.setInt(4, id);
            int rowsUpdated = stmt.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("Artículo actualizado correctamente.");
            } else {
                System.out.println("No se encontró un artículo con ese ID.");
            }
        }
    }

    private static void eliminarArticulo(Connection connection, Scanner scanner) throws SQLException {
        System.out.print("ID del artículo a eliminar: ");
        int id = scanner.nextInt();
        scanner.nextLine(); 

        String query = "DELETE FROM Articulo WHERE id_articulo = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, id);
            int rowsDeleted = stmt.executeUpdate();
            if (rowsDeleted > 0) {
                System.out.println("Artículo eliminado correctamente.");
            } else {
                System.out.println("No se encontró un artículo con ese ID.");
            }
        }
    }

    private static void consultarConFiltros(Connection connection, Scanner scanner) throws SQLException {
        System.out.print("Ingrese un precio mínimo: ");
        double precioMin = scanner.nextDouble();
        scanner.nextLine(); 

        String query = "SELECT * FROM Articulo WHERE precio_inicial >= ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setDouble(1, precioMin);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    System.out.printf("ID: %d, Nombre: %s, Descripción: %s, Precio: %.2f\n",
                            rs.getInt("id_articulo"), rs.getString("nombre"), rs.getString("descripcion"), rs.getDouble("precio_inicial"));
                }
            }
        }
    }

    private static void ordenarArticulos(Connection connection, Scanner scanner) throws SQLException {
        System.out.println("Ordenar por: 1. Nombre 2. Precio inicial");
        int opcion = scanner.nextInt();
        scanner.nextLine(); 

        String orden = (opcion == 1) ? "nombre" : "precio_inicial";
        String query = "SELECT * FROM Articulo ORDER BY " + orden;

        try (Statement stmt = connection.createStatement(); ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                System.out.printf("ID: %d, Nombre: %s, Descripción: %s, Precio: %.2f\n",
                        rs.getInt("id_articulo"), rs.getString("nombre"), rs.getString("descripcion"), rs.getDouble("precio_inicial"));
            }
        }
    }

    private static void consultarConJoin(Connection connection) throws SQLException {
        String query = "SELECT Articulo.nombre AS articulo, Categoria.nombre AS categoria " +
                "FROM Articulo " +
                "JOIN Categoria ON Articulo.id_categoria = Categoria.id_categoria";

        try (Statement stmt = connection.createStatement(); ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                System.out.printf("Artículo: %s, Categoría: %s\n",
                        rs.getString("articulo"), rs.getString("categoria"));
            }
        }
    }
}